import { IsDateString, IsNotEmpty, IsString, IsOptional, IsBoolean } from 'class-validator';

export class DonacionDto {
  @IsDateString()
  @IsNotEmpty()
  fecha: string; 
  
  @IsString()
  @IsNotEmpty()
  Titulo: string;

  @IsString()
  @IsNotEmpty()
  Descripcion: string;

  @IsOptional()
  @IsString()
  imagenUrl: string;
}
